See Wiki:
https://github.com/stm32duino/wiki/wiki/Add-a-new-variant-(board)